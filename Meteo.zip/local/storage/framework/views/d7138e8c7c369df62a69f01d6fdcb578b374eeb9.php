<img src="<?php echo e(URL::asset('img/404.png')); ?>" alt=""/></a>
